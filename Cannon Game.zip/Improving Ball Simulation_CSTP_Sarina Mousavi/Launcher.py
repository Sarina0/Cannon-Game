from graphics import Circle, Point, Line
from math import radians, degrees, sin, cos
from shotTracker import ShotTracker

class Launcher:
    '''create initial launcher with initial angle 45' and velocity 40 m/s.  It receive win, the GraphWin already
    created by the main.'''

    def __init__(self, win):
        self.win = win
        self.radius = 3
        self.angle = 45.0
        self.vel = 40.0
        self.ball = Circle(Point(0, 0), self.radius).draw(win)
        self.ball.setFill("red")
        self.ball.setOutline("red")
        # self.ball.draw(win)

        self.arrow = Line(Point(0, 0), Point(0, 0)).draw(win)  # creating a dummy arrow for now. Will be updated later
        self.redraw()


    # def redraw(self):
    #     '''updates the current arrow graphics to show the new direction and length based on user input received'''
    #     self.arrow.undraw()
    #     endpoint = Point(self.vel * cos(self.angle), self.vel * sin(self.angle))
    #     self.arrow = Line(Point(0, 0), endpoint).draw(self.win)
    #     self.arrow.setArrow("last")
    #     self.arrow.setWidth(3)

    def redraw(self):
        '''updates the current arrow graphics to show the new direction and length based on user input received'''

        self.ball.undraw()
        self.ball = Circle(Point(0, 0), self.radius).draw(self.win)
        self.ball.setFill("red")
        self.ball.setOutline("red")

        self.arrow.undraw()
        endpoint = Point(self.vel * cos(radians(self.angle)), self.vel * sin(radians(self.angle)))
        self.arrow = Line(Point(0, 0), endpoint).draw(self.win)
        self.arrow.setArrow("last")
        self.arrow.setWidth(30)
        self.arrow.setFill("brown")
        self.arrow.setWidth(self.radius * 10)


    def adjAngle(self, da):
        '''change angle by da degrees'''
        self.angle = self.angle + da
        self.redraw()

    def adjVel(self, dv):
        '''change velocity by dv'''
        self.vel = self.vel + dv
        self.redraw()
    def adjRad(self, rad):
        # dim = self.r * 2
        self.radius = self.radius + rad
        self.redraw()

    def fire(self):
        return ShotTracker(self.win, self.angle, self.vel, self.radius, 0.0)



