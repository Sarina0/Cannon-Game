from graphics import Circle, Point
from projectile import Projectile


class ShotTracker:
    '''Graphical representation of a projectile in flight using a circle for its graphics'''

    def __init__(self, win, angle, vel, radius, hei):
        self.projectile = Projectile(angle, vel, hei)
        self.ball = Circle(Point(0, hei), radius)
        self.ball.setFill("green")
        self.ball.setOutline("green")
        self.ball.draw(win)

    def update(self, dt):
        '''moves the ball dt seconds farther along its track'''
        self.projectile.update(dt)
        currentCenter = self.ball.getCenter()
        dx = self.projectile.getX() - currentCenter.getX()
        dy = self.projectile.getY() - currentCenter.getY()
        self.ball.move(dx, dy)

    def undraw(self):
        self.ball.undraw()

    def getX(self):
        return self.projectile.getX()

    def getY(self):
        return self.projectile.getY()

