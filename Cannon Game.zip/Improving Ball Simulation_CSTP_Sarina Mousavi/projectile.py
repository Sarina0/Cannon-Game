from math import radians, sin, cos


class Projectile:
    ''' Numerically simulates the flight of a simple point projectile near the earth's surface, ignoring
    wind and air resistance. Tracking of the projectil is done in 2 dimensions: height(y), and distance (x)'''
    def __init__(self, angle, initVelocity, initHeight = 0.0):
        self.xpos = 0.0
        self.ypos = initHeight
        theta = radians(angle)
        self.xvel = initVelocity * cos(theta)
        self.yvel = initVelocity * sin(theta)

    # if there are other forces to be applied, it should be added bellow. For example air drag force F = - k * vel , vel = (xvel, yvel)
    # So general formula would be newvel = vel + (total Forces ) / mass   * timeInterval
    def update(self, timeInterval):
        newyvel = self.yvel - 9.81 * timeInterval #update based on constant gravity in negative y direction.  acceleration = Force / Mass
        self.xpos = self.xpos + timeInterval * self.xvel
        self.ypos = self.ypos + timeInterval * (self.yvel + newyvel)/2.0
        self.yvel = newyvel


    def getX(self):
        return self.xpos

    def getY(self):
        return self.ypos

#
# from graphics import Circle, Point
# from projectile import Projectile
#
#
# class ShotTracker:
#     '''Graphical representation of a projectile in flight using a circle for its graphics'''
#
#     def __init__(self, win, angle, vel, hei):
#         self.projectile = Projectile(angle, vel, hei)
#         self.ball = Circle(Point(0, hei), 3)
#         self.ball.setFill("green")
#         self.ball.setOutline("green")
#         self.ball.draw(win)
#
#     def update(self, dt):
#         '''moves the ball dt seconds farther along its track'''
#         self.projectile.update(dt)
#         currentCenter = self.ball.getCenter()
#         dx = self.projectile.getX() - currentCenter.getX()
#         dy = self.projectile.getY() - currentCenter.getY()
#         self.ball.move(dx, dy)
#
#     def undraw(self):
#         self.ball.undraw()
#
#     def getX(self):
#         return self.projectile.getX()
#
#     def getY(self):
#         return self.projectile.getY()
#
