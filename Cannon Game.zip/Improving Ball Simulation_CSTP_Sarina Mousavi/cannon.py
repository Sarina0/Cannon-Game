from math import degrees

from graphics import *
from Launcher import Launcher
from button import *


class CannonShotsSim:
    def __init__(self):
        self.win = GraphWin("Cannon Shots Simulator Application", 800, 600)
        self.win.setCoords(-10, -10, 210, 155)
        Line(Point(-10, 0), Point(210, 0)).draw(self.win)

        # create x axis ticks
        for x in range(0, 210, 40):
            Text(Point(x, -7), str(x)).draw(self.win)
            Line(Point(x, 0), Point(x, 2)).draw(self.win)

        # create a launcher
        self.launcher = Launcher(self.win)
        self.shots = []

        # create a target
        # external target
        self.xTarget1Range = (200 - self.launcher.radius * 3, 200)
        self.xTarget1 = Line(Point(self.xTarget1Range[0], 0), Point(self.xTarget1Range[1], 0))
        self.xTarget1.setFill('orange')
        self.xTarget1.setWidth(6)
        self.xTarget1.draw(self.win)
        #     #internal target
        # self.xTraget2Range = (185, 195)
        # xTarget2 = Line(Point(self.xTraget2Range[0], 1), Point(self.xTraget2Range[1], 1))
        # xTarget2.setFill('red')
        # xTarget2.setWidth(3)
        # xTarget2.draw(self.win)

        # score system
        self.score = 0
        self.numShots = 0
        # self.shotsText = Text(Point(10, 135), "Shots: "+str(self.numShots)).draw(self.win)
        self.scoreText = Text(Point(10, 145), "Win track " + str(self.score)).draw(self.win)
        self.intro = Text(Point(100, 150), "*You can use both, the input and keyboard to play the game*").draw(self.win)
        self.winning = Text(Point(100, 135), "").draw(self.win)

        Text(Point(1.5, 110), "Angle").draw(self.win)
        self.angleEntry = Entry(Point(20, 110), 8)
        # self.angleEntry.setText(str(angle))
        self.angleEntry.draw(self.win)

        Text(Point(1.5, 100), "Velocity").draw(self.win)
        self.velEntry = Entry(Point(20, 100), 8)
        # self.velEntry.setText(str(vel))
        self.velEntry.draw(self.win)

        Text(Point(1.5, 90), "Radius").draw(self.win)
        self.raduisEntry = Entry(Point(20, 90), 8)
        # self.heightEntry.setText(str(h))
        self.raduisEntry.draw(self.win)

        self.updateButton = Button(self.win, Point(45, 100), 13.25, 7.5, "Update!")
        self.updateButton.activate()

        self.quitButton = Button(self.win, Point(45, 90), 13.25, 7.5, "Quit")

        self.quitButton.activate()

        self.shotButton = Button(self.win, Point(60, 90), 13.25, 7.5, "Shot")
        self.shotButton.activate()

        self.win.focus_set()
        self.updateLauncher()

    def updateLauncher(self):
        self.angleEntry.setText(self.launcher.angle)
        self.velEntry.setText(self.launcher.vel)
        self.raduisEntry.setText(self.launcher.radius)

    # def updateShots(self, dt):
    #     aliveShots = []
    #     '''update all the shots in their flight path based on time interval dt'''
    #     for shot in self.shots:
    #         shot.update(dt)
    #         # check here if a shot needs to be removed from the list of shot. If so, do it.
    #         if shot.getY() >= 0 and shot.getX() <= 210:
    #             aliveShots.append(shot)
    #         else:
    #             shot.undraw()
    #
    #     self.shots = aliveShots

    def updateShots(self, dt):
        aliveShots = []
        '''update all the shots in their flight path based on time interval dt'''
        for shot in self.shots:
            shot.update(dt)
            # check here if a shot needs to be removed from the list of shot. If so, do it.
            if shot.getY() >= 0 and shot.getX() <= 210:
                aliveShots.append(shot)
            else:
                # winning = Text(Point(100, 135), "SUCCESS! Hurry!").draw(self.win)
                if shot.getY() < 0:
                    if self.xTarget1Range[0] <= shot.getX() <= self.xTarget1Range[1]:
                        # self.score += 1
                        self.winning.setText("Succsses Hurry!")
                        self.score += 1
                        self.scoreText.setText("Track " + str(self.score))
                    else:
                        self.winning.setText("")
                        # self.scoreText.setText("Score: "+str(self.score))
                        self.score = 0
                        self.scoreText.setText("Track " + "")

                    # if self.launcher.fire():
                    #     winning = Text(Point(100, 135), "").draw(self.win)
                    #     self.score += 1
                    #     self.scoreText.setText("Track " + str(self.score))

                shot.undraw()

        self.shots = aliveShots

    # def updateShots(self, dt):
    #     aliveShots = []
    #     '''update all the shots in their flight path based on time interval dt'''
    #
    #     for shot in self.shots:
    #         shot.update(dt)
    #         if self.launcher.fire():
    #             self.score += 1
    #             self.scoreText.setText("Track " + str(self.score))
    #
    #         if self.xTarget1Range[0] <= shot.getX() <= self.xTarget1Range[1]:
    #                     # self.score += 1
    #                     winning = Text(Point(100, 135), "SUCCESS! Hurry!").draw(self.win)
    #         shot.undraw()
    #
    #     self.shots = aliveShots

    # def run2(self):
    #     '''main event loop of the application'''
    #
    #     pt = self.win.getMouse()
    #
    #     if self.updateButton.clicked(pt):
    #         update(self.launcher.adjAngle(float(self.angleEntry.getText())))
    #     if self.updateButton.clicked(pt):
    #         update(self.launcher.adjAngle(float(self.velEntry.getText())))
    #
    #
    #             # if self.updateButton.clicked(pt):
    #         #     update(self.r(float(self.raduisEntry.getText())))
    #         # elif self.shotButton.clicked(pt):
    #         #     self.shots.append(self.launcher.fire())
    #     self.win.getMouse()

    # def run(self):
    #     '''main event loop of the application'''
    #     pt = self.win.getMouse()
    #     while True:
    #         self.updateShots(1/5)
    #
    #         # take care of user interaction
    #         # key = self.win.checkKey()
    #         if self.quitButton.clicked(pt):
    #             self.win.getMouse()
    #             break
    #
    #         if self.updateButton.clicked(pt):
    #             self.win.getMouse()
    #             self.shots.append(self.launcher.fire())
    #
    #
    #     update(5) # update rate of graphics window
    # self.win.getMouse()
    # self.win.close()

    def run(self):
        '''main event loop of the application'''
        # pt = self.win.getMouse()
        while True:
            self.updateShots(1 / 30)

            # input_focus = self.win.focus_get()
            # if not input_focus:
            # angle = self.launcher.angle
            # input_text = self.angleEntry.getText()
            # if input_text != '' and float(input_text) != self.launcher.angle:
            #     input_flag = True

            # vel = float(self.velEntry.getText())
            # if vel != self.launcher.vel:
            #     continue
            # radius = float(self.raduisEntry.getText())
            # if radius != self.launcher.radius:
            #     continue

            # take care of user interaction
            pt = self.win.checkMouse()
            if pt:
                if self.quitButton.clicked(pt):
                    break
                elif self.shotButton.clicked(pt):
                    self.shots.append(self.launcher.fire())
                elif self.updateButton.clicked(pt):
                    self.launcher.adjAngle(float(self.angleEntry.getText()) - self.launcher.angle)
                    self.launcher.adjVel(float(self.velEntry.getText()) - self.launcher.vel)
                    radius = int(self.raduisEntry.getText())
                    if radius > 10:
                        radius = 10
                        self.raduisEntry.setText(radius)
                    self.launcher.adjRad(radius - self.launcher.radius)
                    self.xTarget1Range = (200 - self.launcher.radius * 3, 200)
                    self.xTarget1 = Line(Point(self.xTarget1Range[0], 0), Point(self.xTarget1Range[1], 0))
                    self.xTarget1.setFill('orange')
                    self.xTarget1.setWidth(6)
                    self.xTarget1.draw(self.win)

                    self.win.focus_set()

            key = self.win.checkKey()
            if key in ["q", "Q"]:
                break

            if key == "Up":
                self.launcher.adjAngle(3)
                self.angleEntry.setText(self.launcher.angle)
            elif key == "Down":
                self.launcher.adjAngle(-3)
                self.angleEntry.setText(self.launcher.angle)
            elif key == "Right":
                self.launcher.adjVel(3)
                self.velEntry.setText(self.launcher.vel)
            elif key == "Left":
                self.launcher.adjVel(-3)
                self.velEntry.setText(self.launcher.vel)
            elif key == "plus":
                radius = self.launcher.radius
                if radius < 10:
                    self.launcher.adjRad(1)
                    self.raduisEntry.setText(self.launcher.radius)

                    self.xTarget1Range = (200 - radius * 3, 200)
                    self.xTarget1.undraw()
                    self.xTarget1 = Line(Point(self.xTarget1Range[0], 0), Point(self.xTarget1Range[1], 0))
                    self.xTarget1.setFill('orange')
                    self.xTarget1.setWidth(6)
                    self.xTarget1.draw(self.win)
            elif key == "minus":
                radius = self.launcher.radius
                if radius > 0:
                    self.launcher.adjRad(-1)
                    self.raduisEntry.setText(self.launcher.radius)

                    self.xTarget1Range = (200 - radius * 3, 200)
                    self.xTarget1.undraw()
                    self.xTarget1 = Line(Point(self.xTarget1Range[0], 0), Point(self.xTarget1Range[1], 0))
                    self.xTarget1.setFill('orange')
                    self.xTarget1.setWidth(6)
                    self.xTarget1.draw(self.win)


            if key == "f":
                self.shots.append(self.launcher.fire())

            update(30)  # update rate of graphics window

        self.win.close()


if __name__ == "__main__":
    theApp = CannonShotsSim()
    theApp.run()
    # theApp.run()

    # pt = self.win.getMouse()
    #
    # if self.startButton.clicked(pt):
    #     update(self.launcher.adjAngle(float(self.angleEntry.getText())))
    # if self.startButton.clicked(pt):
    #     update(self.launcher.adjAngle(float(self.velEntry.getText())))
    #
    # self.win.getMouse()
